from flask import render_template as render

def make_pages(flaskapp):

    # Define a route for the home page
    @flaskapp.route("/")
    def home():
        print("working2")
        return render("create.html")


    @flaskapp.route("/index")
    def index():
        return render("index.html")


    @flaskapp.route("/login")
    def login():
        return render("login.html")


    @flaskapp.route("/register")
    def register():
        return render("user-registration.html")


    @flaskapp.route("/create")
    def create():
        return render("create.html")


    @flaskapp.route("/guest")
    def guest():
        return render("guest.html")