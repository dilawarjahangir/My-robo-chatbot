from bs4 import BeautifulSoup
import requests
from py2neo import Graph, Node, Relationship
import aiml
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer


graph = Graph(password="123456789")

k = aiml.Kernel()
k.learn("./std-startup.xml")
print("working")

def make_node(name):
    node1 = graph.nodes.match("Person", name=name).first()
    if node1:
        print("user already exist")
    else:
        node = Node("Person", name=name)
        graph.create(node)
        print("Node created in Neo4j:", node)

# defining make_relation funtion
def make_rel(user_one, relationship, user_two):

    node1 = graph.nodes.match("Person", name=user_one).first()
    node2 = graph.nodes.match("Person", name=user_two).first()
    if node1 and node2:
        relationship = Relationship(node1, relationship, node2)
        graph.create(relationship)
        print("Relationship created in Neo4j:", relationship)


def update_node_properties(label, property_key, property_value, update_properties):
    existing_node = graph.nodes.match(label, **{property_key: property_value}).first()
    if existing_node:
        for key, value in update_properties.items():
            existing_node[key] = value

        graph.push(existing_node)

        print("Node updated successfully!")
    else:
        print("Node not found.")


def make_obj_node(name):
    node1 = graph.nodes.match("Object", name=name).first()
    if node1:
        print("user already exist")
    else:
        node = Node("Person", name=name)
        graph.create(node)
        print("Node created in Neo4j:", node)

def handle_user_request(_query):
    print("UI", _query)
    if "my name" in _query:
        person = k.getPredicate("person")
        make_node(person)
        print(person)
    elif "is my" in _query:
        user_one = k.getPredicate("person1")
        print(user_one)
        user_two = k.getPredicate('person2')
        print(user_two)
        relation = k.getPredicate("relationship")
        print(relation)
        make_node(user_one)
        make_rel(user_one=user_one, relationship=relation, user_two=user_two)
        prolog_fact = f"{relation}({user_one},{user_two})"
        with open(r"pytholog_knowledgeBase.pl", "a") as file:
            file.write("\n" + prolog_fact)
    elif "male" in _query and "fe" in _query:
        person = k.getPredicate("person")
        prolog_fact = f"female({person})"
        with open(r"pytholog_knowledgeBase.pl", "a") as file:
            file.write("\n" + prolog_fact)
        new_properties = {"gender": "female"}
        update_node_properties("Person", "name", person, new_properties)

    elif "male" in _query:
        person = k.getPredicate("person")
        prolog_fact = f"male({person})"
        with open(r"pytholog_knowledgeBase.pl", "a") as file:
            file.write("\n" + prolog_fact)
        new_properties = {"gender": "male"}
        update_node_properties("Person", "name", person, new_properties)

    elif "my age" in _query:
        age = k.getPredicate("add_age")
        person = k.getPredicate("person")
        new_properties = {"age": age}
        update_node_properties("Person", "name", person, new_properties)

    elif "i live" in _query:
        location = k.getPredicate("add_location")
        person = k.getPredicate("person")
        new_properties = {"location": location}
        update_node_properties("Person", "name", person, new_properties)
    elif "like" in _query:
        name = k.getPredicate("person")
        ob_relation = k.getPredicate("relationship")
        ob_name = k.getPredicate("object")
        make_obj_node(ob_name)
        make_rel(user_one=name, relationship=ob_relation, user_two=ob_name)

    if "who" in _query:
        print("i am here")
        search1 = k.getPredicate("who1")
        search2 = k.getPredicate("who2")
        print(search1)
        print(search2)
        fullname = search2 + " " + search2
        print(fullname)
        enter = fullname
        new = enter.replace(" ", "_")
        url = f"https://en.wikipedia.org/wiki/{new}"
        r = requests.get(url)
        html_content = r.content
        soup = BeautifulSoup(html_content, "html.parser").find_all("p")[1].textsoap
        print(soup)

