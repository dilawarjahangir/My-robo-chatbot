#####################
##     imports     ##
#####################

from flask import \
    Flask, \
    render_template as render, \
    request, \
    jsonify
    
import aiml
import os
import pytholog as pl

template_dir = os.path.abspath('templtes')
from nltk.tokenize import word_tokenize, sent_tokenize
from py2neo import Graph, Node, Relationship

import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

import tensorflow as tf
from transformers import \
    BertTokenizer, \
    TFBertForSequenceClassification

from simple_pages import make_pages
from conditions import handle_user_request

# Initialize NLTK components
nltk.download("punkt")
nltk.download("stopwords")
nltk.download("wordnet")
stopwords = set(stopwords.words("english"))
lemmatizer = WordNetLemmatizer()




#####################
##      flast      ##
#####################


def preprocess(text):
    # Tokenize the text into words
    words = word_tokenize(text.lower())

    # Remove stopwords and punctuation
    words = [word for word in words if word.isalnum() and word not in stopwords]

    # Lemmatize the words
    lemmatized_words = [lemmatizer.lemmatize(word) for word in words]

    # Join the lemmatized words back into a single string
    preprocessed_text = " ".join(lemmatized_words)

    return preprocessed_text


kb = pl.KnowledgeBase()


print(template_dir)
# import sys; sys.exit(0)
flaskapp = Flask(__name__, template_folder=template_dir)
flaskapp = Flask(__name__)
graph = Graph(password="123456789")
# graph = Graph("bolt://localhost:7687", auth=("neo4j", "123456789"))

# Load the AIML k
k = aiml.Kernel()
k.learn("./std-startup.xml")
print("working")

make_pages(flaskapp)


@flaskapp.route("/handle_login", methods=["POST"])
def handle_login():
    user_details = request.form
    username = user_details.get("email")
    password = user_details.get("password")

    print(username, password)
    node1 = graph.nodes.match("Person", name=username, password=password).first()
    print(node1)
    if node1:
        response = {"message": "User exist"}
        k.setPredicate("username", username)
        return render("index.html", username=username)
    else:
        print("User not found or incorrect password!")
        response = {"message": "User does not exist"}

    return jsonify(response), 200
    # Perform registration logic here


@flaskapp.route("/handle_register", methods=["POST"])
def handle_registration():
    user_details = request.form
    username = user_details.get("username")
    email = user_details.get("email")
    password = user_details.get("password")
    node1 = graph.nodes.match("Person", name=username, email=email).first()
    gender = get_gender_prediction(username)
    new_properties = {"Gender": gender}
    update_node_properties("Person", "name", username, new_properties)
    if node1:
        print("user already exist")
        response = {"message": "User already exist"}
    else:
        node = Node("Person", name=username, email=email, password=password)
        graph.create(node)
        print("Node created in Neo4j:", node)

        # Perform registration logic here
        response = {"message": "Registration successful"}
    return jsonify(response), 200


# Define a route for processing the input and generating a response
@flaskapp.route("/process", methods=["POST"])
def process():
    # Get the user's input from the requestx
    _query = request.form.get("_query")
    sentence_type = get_sentence_type(_query)
    print(sentence_type)
    _processed = preprocess(_query)
    print(type(_processed))
    print(_query)

    # checking users input
    if _query is None:
        print("no inputss")
        return "Error: Invalid request"
    # Pass the user's input to the AIML k for processing
    response = k.respond(_query)
    handle_user_request(_query=_query)

    # Return the response back to the HTML page
    return response


# defining make_node function


@flaskapp.route("/handle_guest", methods=["POST"])
def handle_guest():
    # Get the user's input from the requestx
    _query = request.form.get("_query")
    _processed = preprocess(_query)
    sentence_type = get_sentence_type(_query)
    print(sentence_type)
    print(type(_processed))
    print(_query)

    # checking users input
    if _query is None:
        print("no inputss")
        return "Error: Invalid request"
    # Pass the user's input to the AIML k for processing
    response = k.respond(_query)
    handle_user_request(_query=_query)

    # Return the response back to the HTML page
    return response


# defining make_node function


model = TFBertForSequenceClassification.from_pretrained(
    "bert-base-uncased", num_labels=2
)
model.load_weights("gender_model_weights.h5")
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")


def predict_gender(name):
    encoding = tokenizer([name], truncation=True, padding=True)
    input_dataset = tf.data.Dataset.from_tensor_slices(dict(encoding)).batch(1)
    predictions = model.predict(input_dataset)
    predicted_label = tf.argmax(predictions.logits, axis=1)[0].numpy()
    gender = "male" if predicted_label == 0 else "female"
    return gender


def get_gender_prediction(text):
    gender = predict_gender(text)
    if gender == "male":
        return f"male"
    else:
        return f"female"


def get_sentence_type(sentence):
    # Tokenize the sentence into words
    words = nltk.word_tokenize(sentence)

    # Get the part-of-speech tags for the words
    tags = nltk.pos_tag(words)

    # Check the tag of the last word to determine the sentence type
    last_word = words[-1]
    last_word_tag = tags[-1][1]

    if last_word_tag == ".":
        # If the last word is a period, it's likely an assertive sentence
        return "assertive"
    elif last_word_tag == "?":
        # If the last word is a question mark, it's an interrogative sentence
        return "interrogative"
    elif last_word_tag == "!":
        # If the last word is an exclamation mark, it's an exclamatory sentence
        return "exclamatory"
    elif last_word.lower() == "please":
        # If the sentence ends with "please", it's an imperative sentence
        return "imperative"
    else:
        # Default to assertive if the sentence type cannot be determined
        return "assertive"

def make_node(name):
    node1 = graph.nodes.match("Person", name=name).first()
    if node1:
        print("user already exist")
    else:
        node = Node("Person", name=name)
        graph.create(node)
        print("Node created in Neo4j:", node)


def update_node_properties(label, property_key, property_value, update_properties):
    existing_node = graph.nodes.match(label, **{property_key: property_value}).first()
    if existing_node:
        for key, value in update_properties.items():
            existing_node[key] = value

        graph.push(existing_node)

        print("Node updated successfully!")
    else:
        print("Node not found.")


# Run the Flask flaskapp
if __name__ == "__main__":
    flaskapp.run(port=8000)
